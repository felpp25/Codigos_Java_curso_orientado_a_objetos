package Ex2;

public class Quadrado {
	double lado;
	
	public Quadrado(double lado){
		this.lado = lado;
	}
	
	public double calculaArea(double area) {
		area = lado * lado;
		return area;		
	}
	public double calculaPerimetro(double perimetro) {
		perimetro = 4.0 * lado;
		return perimetro;
	}
}
