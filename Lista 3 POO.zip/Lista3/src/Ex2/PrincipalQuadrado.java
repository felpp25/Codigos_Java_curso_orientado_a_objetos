package Ex2;

import java.util.Scanner;

public class PrincipalQuadrado {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		double lado = 0;
		double perimetro = 0;
		double area = 0;
		double result1, result2, result3;
		double parametroResult1, parametroResult2, parametroResult3;
		

		System.out.print("Informe o lado do quadrado: ");
		lado = ler.nextDouble();

//		instanciar e chamar o metodo perimetro e area
		Quadrado Q1 = new Quadrado(lado);
		parametroResult1 = Q1.calculaPerimetro(perimetro);
		result1 = Q1.calculaArea(area);
		System.out.println("Area: " + result1 + "\t Perimetro: " + parametroResult1);

		
		System.out.println("\n");

		
		System.out.print("Informe o lado do quadrado: ");
		lado = ler.nextDouble();
		Quadrado Q2 = new Quadrado(lado);
		parametroResult2 = Q2.calculaPerimetro(perimetro);
		result2 = Q2.calculaArea(area);
		System.out.println("Area: " + result2 + "\t Perimetro: " + parametroResult2);
		
		
		System.out.println("\n");
		
		
		System.out.print("Informe o lado do quadrado: ");
		lado = ler.nextDouble();
		Quadrado Q3 = new Quadrado(lado);
		parametroResult3 = Q3.calculaPerimetro(perimetro);
		result3 = Q3.calculaArea(area);
		System.out.println("Area: " + result3 + "\t Perimetro: " + parametroResult3);
		ler.close();
	}

}
