package Ex1;

public class Funcionario {
	double salario;

	public double calculaSalario (double salario) {
		

		if (salario > 8000 ) {
			salario = (salario * (8.675/100) + 382.33);
		}
		else {
			salario = (salario *  (3.87/100) + 177.12);
			
		}
		return salario;
	}

}
