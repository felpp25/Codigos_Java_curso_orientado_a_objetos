package Ex1;

import java.util.Scanner;

public class FuncionarioTeste {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
	
		
		System.out.print("Informe o valor do salario: ");
		double salario = ler.nextDouble();
		
		Funcionario CS = new Funcionario();
		
		double salarioFinal = CS.calculaSalario(salario);
		System.out.print(+salarioFinal);
		ler.close();	
		}
	}

