package Lista2;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {		
			Scanner ler = new Scanner (System.in);
			int x, y, i, z;
			
			
			System.out.print("Informe o valor de X difernte de 0: ");
			x = ler.nextInt();
			System.out.print("Informe o valor de Y difernte de 0: ");
			y = ler.nextInt();
			
			z = x;
			for(i = 1 ; i < y ; i++){
			    x = x * z;
			}
			System.out.print("O valor da pontecia: "+x);
		}


	}

