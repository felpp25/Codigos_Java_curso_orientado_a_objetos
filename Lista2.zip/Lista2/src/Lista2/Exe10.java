package Lista2;

import java.util.Scanner;

public class Exe10 {

	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		int x, aux, i, z; 
		System.out.print("Informe um numero inteiro a ser fatorado: ");
		x = ler.nextInt();
		aux = 1; 
		z = x;
		for(i=0; i<z ; i++) {
			aux = aux * x;
			x = x-1;
		}
		System.out.print("Numero fatorado: "+aux);
	}

}
