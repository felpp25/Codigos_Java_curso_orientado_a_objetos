package Lista2;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		double salario, salariofinal, valoraumento;
		int codigo, porcentagem;
		String cargo;
		
		
		System.out.println("(1)-Escriturario:" );
		System.out.println("(2)-Secretario:" );
		System.out.println("(3)-Caixa:" );
		System.out.println("(4)-Gerente:" );
		System.out.println("(5)-Diretor:" );
		System.out.println("(0)-Sair:" );
		System.out.println("Informe o codigo do funcionario:\n ");
		codigo = ler.nextInt();
		System.out.println("Informe o salario do funcionario:\n ");
		salario = ler.nextDouble();
		salariofinal = 0;
		switch (codigo) {
		case 0:
			break;
		case 1:
			salariofinal = salario * 0.5;
			break;
		case 2:
			salariofinal = salario * 0.35;
			break;	
		case 3:
			salariofinal = salario * 0.2;
			break;	
		case 4:
			salariofinal = salario * 0.1;
			break;	
		case 5:
			System.out.print("Sem aumento!");
			break;
		}  	
		valoraumento = 	salario - salariofinal;
		System.out.println("Cargo:\n"+codigo);
		System.out.println("Salario:\n"+salario);
		System.out.println("Valor do aumento do funcionario:\n "+valoraumento);
		
	}

}
