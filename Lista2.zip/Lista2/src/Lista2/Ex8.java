package Lista2;
import java.lang.Math;
import java.util.Scanner;

public class Ex8 {

	public static void main(String[] args) {
		
			Scanner ler = new Scanner (System.in);
				double fxy;
				int x, y, codigo;
				x = 0;
				y = 0;
				codigo = 0;
				fxy = 0;
				
				System.out.print("Informe o valor de X sendo este maior que 0: ");
				x = ler.nextInt();
				System.out.print("\n");
				System.out.print("Informe o valor de Y sendo este maior que 0: ");
				y = ler.nextInt();
				
				System.out.print("O sistema devera calcular a f(x,y) de acordo com o CODIGO de 1 a 4 que usuario solicitar!");
				System.out.print("\n");
				System.out.println("(1)- 𝑓(x, y) = raiz(𝑥3 +(x(2y − x)))." );
				System.out.println("(2)-𝑓(x, y) =raiz((𝑥3 + 𝑦3) + (x3 − y3)) /x ∗ y." );
				System.out.println("(3)-𝑓(x, y) = 2𝑥 + raiz(x * y)." );
				System.out.println("(4)-𝑓(x, y) = sin(x) + cos(y)." );
				System.out.print("\n");
				System.out.print("informe o codigo da f(x,y): ");
				codigo = ler.nextInt();
				
				if (codigo < 0 || codigo > 4 ){
				    System.out.print("Codigo da funcao invalido:\n ");
				    System.out.print("Informe o codigo de 1 a 4:\n ");
				    codigo = ler.nextInt();
				    System.out.print("\n");
				}
				
				switch (codigo) {
				case 0: 
					break;
				case 1:
				    fxy = Math.sqrt(Math.pow(x, 3)+(x*(2*y-x))/Math.pow(y, 2));
					break;
				case 2:
					fxy = Math.sqrt((Math.pow(x, 3)+Math.pow(y, 3))+(Math.pow(x, 3)-Math.pow(y, 3)))/x*y;
					break;	
				case 3:
				    fxy = 2*x + (Math.sqrt(x*y));
					break;	
				case 4:
					fxy = Math.sin(x) + Math.cos(y);;
					break;	
			    }
			
			    System.out.print("Resultado da f(x,y): "+fxy);

		}
	

}
