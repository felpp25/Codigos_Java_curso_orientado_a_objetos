package Exercicios;

import java.util.Scanner;

public class Ex1 {
		
	public static void main(String[] args) {

	Scanner ler = new Scanner(System.in);
		
	int ano;
	String nome1, nome2;  		
	
	ano = 2018;
	nome1 = "Fulano da Silva"; 
	nome2 = "Ciclana de Souza"; 
	
	System.out.println(nome1+" e casado com "+nome2+" ha "+ano+" anos.");
	
	
	
		

	}

}
